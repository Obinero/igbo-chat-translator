const fetch = require("node-fetch");

exports.handler = async function(event, context) {
  const { inputText, direction } = JSON.parse(event.body);
  const prompt = direction === "en-to-ig"
    ? `Translate this English to Igbo:\n\n${inputText}`
    : `Translate this Igbo to English:\n\n${inputText}`;

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2
    })
  });

  const data = await response.json();
  return {
    statusCode: 200,
    body: JSON.stringify({ result: data.choices[0].message.content })
  };
};
